<!doctype html>
<html>
<head>
	<title>Teman Saya</title>
	<link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="lib/bootstrap/css/bootstrap-theme.min.css">
	<link rel="stylesheet" href="lib/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/teman.css">
</head>
<body>

	<div class="page-header">
		<h1>Teman Saya</h1>
	</div>

	<a class="btn btn-success" href="#" role="button"><i class="fa fa-plus-circle" aria-hidden="true"></i>
Tambah Teman</a>

	<table class="table table-bordered"> 
		<tr>
			<td>Nama</td>
			<td>Gender</td>
			<td>Email</td>
			<td>Facebook</td>
			<td>Foto</td>
			<td>Aksi</td>
		</tr>
		
	</table>

	
 	<script src="lib/jquery/jquery-3.2.0.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>