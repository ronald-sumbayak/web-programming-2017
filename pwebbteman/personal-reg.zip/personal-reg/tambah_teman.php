<!doctype html>
<html>
<head>
	<title>Tambah Teman Saya</title>
	<link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="lib/bootstrap/css/bootstrap-theme.min.css">
	<link rel="stylesheet" href="lib/font-awesome-4.7.0/css/font-awesome.min.css">
</head>
<body>

	<div class="page-header">
		<h1>Tambah Teman Baru</h1>
	</div>
	
	<form>
		<div class="form-group">
		    <label for="nama">Nama</label>
		    <input type="text" class="form-control" id="nama" placeholder="Nama">
		</div>
		<div class="form-group">
		    <label for="gender">Gender</label>
		    <label class="radio-inline">
			  <input type="radio" name="gender" id="genderRadio1" value="option1"> L
			</label>
			<label class="radio-inline">
			  <input type="radio" name="gender" id="genderRadio2" value="option2"> P
			</label>
		</div>
		<div class="form-group">
		    <label for="email">Email</label>
		    <input type="email" class="form-control" id="email" placeholder="Email">
		</div>
		<div class="form-group">
		    <label for="nama">Facebook</label>
		    <input type="text" class="form-control" id="nama" placeholder="Facebook">
		</div>
		<div class="form-group">
			<label for="nama">Foto</label>
		    <input type="file"  name="foto" id="foto">
		</div>

		<button type="submit" class="btn btn-default">Simpan</button>
	</form>

	
 	<script src="lib/jquery/jquery-3.2.0.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>